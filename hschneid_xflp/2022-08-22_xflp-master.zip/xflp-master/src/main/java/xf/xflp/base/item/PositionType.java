package xf.xflp.base.item;

public enum PositionType {

    TMP,
    ROOT,
    BASIC,
    EXTENDED_H,
    EXTENDED_V;

}
